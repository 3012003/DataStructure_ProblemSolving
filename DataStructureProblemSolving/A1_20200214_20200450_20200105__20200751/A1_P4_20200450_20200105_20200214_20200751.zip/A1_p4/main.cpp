#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

void display(string s, int n)
{
    for (int i = 0; i < n; i++) {
        cout << s[i];
    }
    cout << endl;
}

void Permutations(string s, int n)
{

    // Sort the given array
    sort(s.begin(), s.end());

    // Find all possible permutations
    cout << "Possible permutations are:\n";
    do {
        display(s, n);
    } while (next_permutation(s.begin(), s.end()));
}

// Driver code
int main()
{
    string s;
    cin >> s;
    int n = s.length();

    Permutations(s, n);

    return 0;
}
