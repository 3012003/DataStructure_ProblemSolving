#include "fraction_calculator.h"
#include "fraction.h"
using namespace std;

fraction_calculator::fraction_calculator(){}

void fraction_calculator::FractionCalculator()
{
    fraction num1,num2;
    cout<<"please enter the first fraction"<<endl;
    cin>>num1;
    cout<<"please enter the second fraction"<<endl;
    cin>>num2;
    int oper;
    cout<<"please enter the number of only this operations'adding,subtracting,multiplying,dividing' do you to do"<<endl;
    int n,i=0;
    cin>>n;
    // i assume that he want to store the result of each operation
    fraction result[n];
    while(true)
    {
       cout<<"please enter the number of operation you want to do such as add=1,subtracting=2, multiplying=3, dividing=4 "<<endl;
       cout<<"and comparing such as greater than=5, less than=6, greater than or equal=7, less than or equal=8, equal=9"<<endl;
       cout<<"if you want to exit enter 10 "<<endl;
       cin>>oper;
       if(oper==1)
        {
            result[i]=num1+num2;
            cout<<num1<<" + "<<num2<<"="<<result[i]<<endl;
            i++;


        }
        if(oper==2)
        {
            result[i]=num1-num2;
            cout<<num1<<"-"<<num2<<"="<<result[i]<<endl;
            i++;


        }
        if(oper==3)
        {
            result[i]=num1*num2;
            cout<<num1<<"*"<<num2<<"="<<result[i]<<endl;
            i++;


        }
        if(oper==4)
        {
            result[i]=num1/num2;
            cout<<num1<<"/"<<num2<<"="<<result[i]<<endl;
            i++;

        }
        //comparing operation

        if(oper==5)
        {
              if(num1>num2)
                  cout<<num1<<">"<<num2<<" 'num1 greater than num2 '"<<endl;
                  i++;

        }
        if(oper==6)
        {
              if(num1<num2)
                  cout<<num1<<"<"<<num2<<" 'num1 less than num2 '"<<endl;
                  i++;

        }
        if(oper==7)
        {
              if(num1>=num2)
                  cout<<num1<<">="<<num2<<" 'num1 greater than or equal num2 '"<<endl;
                  i++;

        }
        if(oper==8)
        {
              if(num1<=num2)
                  cout<<num1<<"<="<<num2<<" 'num1 less than or equal num2 '"<<endl;
                  i++;


        }
        if(oper==9)
        {
              if(num1==num2)
                 cout<< num1<<"="<<num2<<" 'the numbers are equal' "<<endl;
                 i++;

        }
        if(oper==10){
            cout<<"EXIT"<<endl;
            break;
        }

    }
    for(int j=0;j<n;j++)
    {
       cout<<result[j]<<endl;
    }



}
