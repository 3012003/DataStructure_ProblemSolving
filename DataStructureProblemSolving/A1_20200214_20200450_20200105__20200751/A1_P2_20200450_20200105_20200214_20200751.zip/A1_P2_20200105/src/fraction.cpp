#include "fraction.h"
#include<iostream>
#include<cmath>
using namespace std;

fraction::fraction(){}
fraction::fraction(int n,int d)
{
    num=n;
    denum=d;
    this->reduce();
}

//to find the greatest divisor
int fraction::gcd(int n,int d)
{
   int temp;
   d=abs(denum);
   n=abs(num);
   while(temp=n%d)
   {
     n=d;
     d=temp;
   }
   return d;
}
//this method to simplify the fraction
void fraction::reduce()
{
    int div=gcd(num,denum);
    num/=div;
    denum/=div;
    if(denum< 0)
    {
       denum=-denum;
       num=-num;
    }
}

//metodes to add or subtract or multiply or divide
fraction fraction::operator+(const fraction &obj)
{
    fraction temp;
    if(obj.denum==denum){
        temp.num=num+obj.num;
        temp.denum=obj.denum;
        temp.reduce();
        return temp;
    }
    else{
        temp.denum=denum*obj.denum;
        temp.num=(num*obj.denum)+(denum*obj.num);
        temp.reduce();
        return temp;
    }

}
fraction fraction::operator-(const fraction &obj)
{
    fraction temp;
    if(obj.denum==denum){
        temp.num=num-obj.num;
        temp.denum=obj.denum;
        temp.reduce();
        return temp;
    }
    else{
        temp.denum=denum*obj.denum;
        temp.num=(num*obj.denum)-(denum*obj.num);
        temp.reduce();
        return temp;
    }

}
fraction fraction::operator*(const fraction &obj)
{
    fraction temp;
    temp.denum=denum*obj.denum;
    temp.num=num*obj.num;
    temp.reduce();
    return temp;
}
fraction fraction::operator/(const fraction &obj)
{
    fraction temp;
    temp.denum=denum*obj.num;
    temp.num=num*obj.denum;
    temp.reduce();
    return temp;
}

//comparison methods such as(>,<,>=,<=,==)
bool fraction::operator>(const fraction &obj)
{
    int this_nume,c_nume,common_deno;
    this_nume=num*obj.denum;
    c_nume=obj.num*denum;
    common_deno=denum*obj.denum;
    if ((this_nume-c_nume)*common_deno>0)
        return true;
    else
        return false;
}
bool fraction::operator>=(const fraction &obj)
{
    int this_nume,c_nume,common_deno;
    this_nume=num*obj.denum;
    c_nume=obj.num*denum;
    common_deno=denum*obj.denum;
    if ((this_nume-c_nume)*common_deno>=0)
        return true;
    else
        return false;
}
bool fraction::operator<=(const fraction &obj)
{
    int this_nume,c_nume,common_deno;
    this_nume=num*obj.denum;
    c_nume=obj.num*denum;
    common_deno=denum*obj.denum;
    if ((this_nume-c_nume)*common_deno<=0)
        return true;
    else
        return false;
}
bool fraction::operator==(const fraction &obj)
{
    int this_nume,c_nume,common_deno;
    this_nume=num*obj.denum;
    c_nume=obj.num*denum;
    common_deno=denum*obj.denum;
    if ((this_nume-c_nume)*common_deno==+0)
        return true;
    else
        return false;
}
bool fraction::operator<(const fraction &obj)
{
    int this_nume,c_nume,common_deno;
    this_nume=num*obj.denum;
    c_nume=obj.num*denum;
    common_deno=denum*obj.denum;
    if ((this_nume-c_nume)*common_deno<0)
        return true;
    else
        return false;
}

//to be able to input or output fraction
istream &operator>>(istream &in,fraction &obj)
{
    char x;
    in>>obj.num>>x>>obj.denum;
    obj.reduce();
    return in;
}
ostream &operator<<(ostream &out,fraction &obj)
{
    out<<obj.num<<"/"<<obj.denum<<endl;
    return out;
}
