#ifndef FRACTION_CALCULATOR_H
#define FRACTION_CALCULATOR_H
#include "fraction.h"
using namespace std;


class fraction_calculator
{

 public:

     //default constructor
    fraction_calculator();

    //method calculator
    void FractionCalculator();
};

#endif // FRACTION_CALCULATOR_H
