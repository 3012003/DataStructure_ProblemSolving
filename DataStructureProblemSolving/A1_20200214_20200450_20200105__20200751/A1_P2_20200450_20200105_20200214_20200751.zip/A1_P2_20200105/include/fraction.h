#ifndef FRACTION_H
#define FRACTION_H
#include<iostream>
using namespace std;

class fraction{
private:
    int num;
    int denum;
public:
    fraction();
    fraction(int n,int d);

    //simply method of fraction
    void reduce();
    int gcd(int,int);

    //adding, subtracting, multiplying, dividing operations
    fraction operator+(const fraction &obj);
    fraction operator-(const fraction &obj);
    fraction operator*(const fraction &obj);
    fraction operator/(const fraction &obj);

    //comparing operations
    bool operator<(const fraction &obj);
    bool operator>(const fraction &obj);
    bool operator==(const fraction &obj);
    bool operator>=(const fraction &obj);
    bool operator<=(const fraction &obj);

    //I/O operators to be able to input and output fractions naturally
    friend istream &operator>>(istream &in,fraction &obj);
    friend ostream &operator<<(ostream &out,fraction &obj);

};
#endif // FRACTION_H
