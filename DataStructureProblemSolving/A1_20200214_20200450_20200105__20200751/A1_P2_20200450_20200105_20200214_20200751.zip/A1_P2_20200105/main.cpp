#include <iostream>
#include "fraction_calculator.h"

using namespace std;


int main()
{
    fraction_calculator obj;
    obj.FractionCalculator();
    return 0;
}
