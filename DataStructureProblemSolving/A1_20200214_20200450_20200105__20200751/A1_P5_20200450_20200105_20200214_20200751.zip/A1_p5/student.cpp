
#include "student.h"
#include<string>
#include<vector>
#include <iostream>

StudentName::StudentName(string n):name{n}  {
    vector<string> arr;
    string temp;
    for(int i = 0 ; i<name.length() ; i++ )
    {
        if(name[i] == ' ')
        {
            arr.push_back(temp);
            temp = "";
        }
        else
            temp += name[i];
    }
    arr.push_back(temp);
    while(arr.size() < 3 )
    {
        arr.push_back(arr[arr.size()-1]);
    }
    name = "";
    for(string x : arr)
        name += x + '\n';
}


void StudentName::print() {
    cout << name << endl;

}

bool StudentName::replace(int x, int y) {
    vector<string> arr;
    string temp;

    for(int i = 0 ; i<name.length() ; i++ )
    {
        if(name[i] == '\n')
        {
            arr.push_back(temp);
            temp = "";
        }
        else
            temp += name[i];
    }
    if(!temp.empty())
        arr.push_back(temp);
    if( x < 0 || y < 0 || x > arr.size() || y> arr.size() )
        return false;
    swap(arr[x-1] , arr[y-1]);
    name = "";
    for(string x : arr)
        name += x + '\n';
    return true;
}
