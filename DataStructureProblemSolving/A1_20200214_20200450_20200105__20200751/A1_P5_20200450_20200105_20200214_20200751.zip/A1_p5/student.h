//
// Created by EGYPT on 4/27/2022.
//

#ifndef MAIN_CPP_STUDENT_H
#define MAIN_CPP_STUDENT_H


#include<string>
using namespace std;
class StudentName{
private:
    string name ;
public:
    StudentName(string n);
    void print();
    bool replace(int x , int y );
};


#endif //MAIN_CPP_STUDENT_H
