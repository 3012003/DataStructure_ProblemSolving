#include <iostream>
#include <string>
#include"student.h"
using namespace std;
int main() {

    cout <<"first test case:\n";
    string x = "mohamed sayed" ;
   // getline(cin,x);
    StudentName S1(x);
    S1.replace(1,3);
    S1.print();
    //////////////////
    cout <<"second test case:\n";
    string y = "mahmoud fawzy ibrahim" ;
    StudentName S2(y);
    S2.replace(1,3);
    S2.print();
    ///////////////////////////////////////
    cout <<"third test case:\n";
    string z = "fathy" ;
    StudentName S3(z);
    S3.print();
    //////////////////////////////////////
    cout <<"fourth test case:\n";
    string v = "mohamed salah" ;
    StudentName S4(v);
    S4.replace(1,5);
    S4.print();
    ////////////////////////////////////
    cout <<"fifth test case:\n";
    string h = "ahmed alaa ali sayed mohamed" ;
    StudentName S5(h);
    S5.replace(1,4);
    S5.print();
    return 0;
}
