#include <iostream>
using namespace std;

// 2 member functions in iterator class
template<class T>
class node
{
public:
    T item;
    node<T>* next_item;
};


template<class T>
class myList
{

private:
    node<T>* tail;
    node<T>* head;
public:

    class iterator
    {
    public:
        node<T>* no;
        node<T>* heItem;
    public:

        iterator()
        {
            no = nullptr;
            heItem = nullptr;
        }


        iterator(node<T>* ptr, node<T>* h)
        {
            no = ptr;
            heItem = h;
        }

        void operator++()
        {
            if (no->next_item == NULL)
            {
                cout << "Out of Range\n";
                return;
            }
            no = no->next_item;
        }

        // -- operator



        // * operator
        T&operator *()
        {
            return no->item;
        }

        bool operator==(iterator& itr)
        {
            if(no == itr.no)
                return true;
            else
                return false;
        }

        bool operator!=(const iterator& itr)
        {
            if(no == itr.no)
                return false;
            else
                return true;
        }

    };

    // default constructor
    myList()
    {
        head = NULL;
        tail = NULL;
    }

    // parametrized constructor
    myList(T value, int initial_size)
    {
        node<T>* tmp = new node<T>;
        tmp->item = value;
        tmp->next_item = NULL;
        head = tmp;
        tail = tmp;
        tmp = NULL;
        for (int i = 0; i < initial_size - 1; ++i) {
            node<T>* tmp = new node<T>;
            tmp->item = value;
            tmp->next_item = NULL;
            tail->next_item = tmp;
            tail = tmp;
        }
    }

    // destructor
    ~myList()
    {
        while (head != tail)
        {
            node<T>* prev = new node<T>;
            node<T>* cu = new node<T>;
            cu = head;
            while (cu->next_item != NULL)
            {
                prev = cu;
                cu = cu->next_item;
            }
            tail = prev;
            prev->next_item = NULL;
            delete cu;
        }
        delete head;
        delete tail;

    }

    // return the size
    int size()
    {
        int res{};
        node<T>* temp = new node<T>;
        temp = head;
        while (temp != NULL)
        {
            ++res;
            temp = temp->next_item;
        }
        cout<<res<<endl;
        return res;
    }

    // erase
    iterator erase(iterator position)
    {
        node<T>* dele = position.no->next_item;
        position.no->next_item = position.no->next_item->next_item;
        if (dele == tail)
            tail = position.no;
        delete dele;
        return position;
    }


    // assignemnt operator
    myList<T>& operator = (myList<T> another_list)
    {
        iterator it=another_list.begin();
        if(this==&another_list){
            return*this;
        }
        this->push_back(*it);
        while(it!=another_list.end())
        {
            ++it;
            this->push_back(*it);
        }
        return *this;

    }


    // begin & end
    iterator begin() {
        return iterator(head, head);
    }

    iterator end() {
        return iterator(tail, head);
    }


    void push_back(T value)
    {
        node<T>* l = new node<T>;
        l->item = value;
        l->next_item = nullptr;
        if (head == nullptr)
        {
            head = l;
            tail = l;
            l = nullptr;
        }
        else
        {
            tail->next_item = l;
            tail = l;
        }
    }

    void delete_position(int pos)
    {
        // if list is empty
        if(head == NULL)
            return ;

        node<T>* cu = new node<T>;
        cu = head;
        node<T>* prev = new node<T>;
        for (int i = 1; i < pos; i++)
        {
            prev = cu;
            cu = cu->next_item;
        }
        prev->next_item = cu->next_item;
    }

    void insert(int pos, T value)
    {
        node<T>* pre = new node<T>;
        node<T>* cur = new node<T>;
        node<T>* temp = new node<T>;
        cur = head;
        for (int i = 1; i < pos; i++)
        {
            pre = cur;
            cur = cur->next_item;
        }
        temp->item = value;
        pre->next_item = temp;
        temp->next_item = cur;
    }



};

int main()
{
    myList<int> List;
    List.push_back(3);
    List.push_back(8);
    List.push_back(9);
    List.push_back(10);
    cout<<"the list size is: ";
    List.size();
    List.insert(5,2);
    cout<<"the list size after insert is: ";
    List.size();
    List.delete_position(5);
    cout<<"the list size after delete is: ";
    List.size();
    myList<int>::iterator it =List.begin();
    ++it;
    cout<< *it<<endl;
    ++it;
    cout<<*it<<endl;
    List.push_back(5);
    cout<<"the list size is: ";
    List.size();
    myList<int>::iterator it2 =List.end();
    cout<<*it2<<endl;
    List.erase(it2);
    myList<int>list2;
    list2=List;

    return 0;
}
