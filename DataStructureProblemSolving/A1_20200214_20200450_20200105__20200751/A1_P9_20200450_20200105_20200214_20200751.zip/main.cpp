#include <iostream>
#include <ctime>
#include <chrono>
#include<bits/stdc++.h>
using namespace std;


void swapp(int *xp, int *yp)
{
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}


class Sorter
{
public:
    virtual void Sort(int arr[], int n)
    {
        cout<<"I am in the Parent class"<<endl;
    }
};
class SelectionSort: public  Sorter
{
    public:
        void Sort(int arr[], int n)
        {
             int i, j, mini;

              for (i = 0; i < n-1; i++)
             {
                  mini = i;
                 for (j = i+1; j < n; j++)
                   if (arr[j] < arr[mini])
                      mini = j;

                 // Swap the found minimum element with the first element
                 swapp(&arr[mini], &arr[i]);
             }
      }
};

class QuickSort: public Sorter
{
public:

    void Sort(int* arr, int n)
    {
        int pivot = arr[n-1];
        int high = 0;
        for (int i = 0; i < n-1; i++)
        {
                if (arr[i] < pivot)
                {
                        // Swap largest element with this
                        swapp(&arr[i], &arr[high]);
                        high++;
                }
        }
        // swap pivot with xArray[lIndexOfLargestElement]
         swapp(&arr[high], &arr[n-1]);

        if (high > 1)
                Sort(arr, high);
        if (n-high-1 > 1)
                Sort(arr+high+1,n-high-1);


    }
};
class Testbed
{
public:
    int* generateRandom(int,int,int);
    int* generateReverse(int,int,int);

   double RunOnce(string So, int arr[], int n)
   {

       if(So=="selectionSort"){
         Sorter *Sorter_ptr;
         SelectionSort Selection_obj;

         Sorter_ptr = &Selection_obj;
         auto start = chrono::high_resolution_clock::now();

         Sorter_ptr->Sort(arr, n);

         auto end = chrono::high_resolution_clock::now();

         double time_taken=chrono::duration_cast<chrono::nanoseconds>(end - start).count();
         return time_taken;
       }
        else if(So=="quicksort"){
            Sorter *Sorter_ptr;
            QuickSort Quick_obj;

         Sorter_ptr = &Quick_obj;
         auto start = chrono::high_resolution_clock::now();

         Sorter_ptr->Sort(arr, n);

         auto end = chrono::high_resolution_clock::now();
         double time_taken=chrono::duration_cast<chrono::nanoseconds>(end - start).count();
         return time_taken;
        }

  }



 RunAndAverage(Sorter, string type, int mini,int maxi, int sz, int sets_num[])
 {

 }
};
int* Testbed::generateRandom(int Min,int Max,int Size)
{
    int arr[Size];
    for(int i=0;i<Size;i++){
       arr[i]=rand()%(Max-Min+1)+Min;
    }
    return arr;
}
int* Testbed::generateReverse(int Min,int Max,int Size)
{
    int arr[Size];
    for(int i=0;i<Size;i++){
        arr[i]=rand()%(Max-Min+1)+Min;
    }
    sort(arr,arr+Size,greater<int>());
    return arr;
}



//RunAndAverage(sorter, type, min, max, size, sets_num)
int main()
{
    Testbed obj;

    Sorter *Sorter_ptr;
     SelectionSort Selection_obj;

    Sorter_ptr = &Selection_obj;

    int n;
    cout<<"enter the size"<<endl;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }



    //To get Selection Sort Time
    cout<<"please enter the type of sort as selectionsort or quicksort"<<endl;
    string so;
    cin>>so;
    obj.RunOnce(so,arr,n);




return 0;
}
