#include <iostream>
#include <algorithm>
#include <ctime>
#include <chrono>

/*

	Time Complexity of Normal Insertion Sort
	Best Case: O(n) Linear time
	Average Case: O(n^2) Quadratic Time
	Worest Case: O(n^2) Quadratic Time


	Time Complexity of Binary Insertion Sort
	Best Case:O(nLon(n))
	Average Case: O(nLon(n))
	Worest Case: O(nLon(n))

*/

using namespace std;
using namespace std::chrono;
int binarySearch(int arr[], int i, int l, int h)
{
	if (h <= l)
		return (i > arr[l]) ? (l + 1) : l;
	int mid = (l + h) / 2;
	if (i == arr[mid])
		return mid + 1;
	if (i > arr[mid])
		return binarySearch(arr, i, mid + 1, h);
	return binarySearch(arr, i, l, mid - 1);
}
void binaryInsertionSort(int arr[], int n)
{
	for (int i = 1; i < n; i++)
	{
		int current = arr[i];
		int j = i - 1;
		int position = binarySearch(arr, current, 0, j);
		while (j >= position)
		{
			arr[j + 1] = arr[j];
			j--;
		}
		arr[j + 1] = current;
	}
}
void normalInsertionSort(int arr[], int n)
{
	for (int i = 1; i < n; i++)
	{
		int current = arr[i];
		int j = i - 1;
		while (j >= 0 && arr[j] > current)
		{
			arr[j + 1] = arr[j];
			j--;
		}
		arr[j + 1] = current;
	}
}

int main()
{

	cout << "Results from Normal Insertion Sort:\n\n";
	int times;
	cout << "Enter number of times you want to repete the experiment: ";
	cin >> times;

	for (int counter = 0; counter < times; counter++)
	{
		int n;
		cout << "\nEnter size of input: ";
		cin >> n;

		// generate an array of random numbers with size n
		int* ptr = new int[n];
		srand(time(0));
		for (int i = 0; i < n; i++)
		{
			int tmp = rand() % 100000;
			ptr[i] = tmp;
		}

		auto start = high_resolution_clock::now();

		normalInsertionSort(ptr, n);

		auto end = high_resolution_clock::now();

		auto duration = duration_cast<microseconds>(end - start);
		cout << "The execution time of sorting " << n << " elements using normal insertion sort is: ";
		cout << duration.count() << " microseconds\n";

	}



	// Binary Insertion Sort
	cout << "Results from Binary Insertion Sort:\n\n";

	cout << "Enter number of times you want to repete the experiment: ";
	cin >> times;

	for (int counter = 0; counter < times; counter++)
	{
		int n;
		cout << "\nEnter size of input: ";
		cin >> n;

		// generate an array of random numbers with size n
		int* ptr = new int[n];

		for (int i = 0; i < n; i++)
		{
			int tmp = rand() % 100000;
			ptr[i] = tmp;
		}

		auto start = high_resolution_clock::now();

		binaryInsertionSort(ptr, n);

		auto end = high_resolution_clock::now();

		auto duration = duration_cast<microseconds>(end - start);
		cout << "The execution time of sorting " << n << " elements using Binary insertion sort is: ";
		cout << duration.count() << " microseconds\n";

	}


	return 0;
}