#include <iostream>
#include "big_decimal.h"
using namespace std;

int main() {
    bool program_on = true;
    while (program_on) {
        cout << "HI! this is  FCI Calculator\n---------------\n1- do Addition.\n2- do Subtraction.\n3- Exit.\n";
        int ClientNumber;
        cin >> ClientNumber;
        string FirstNumber, SecondNumber;
        try {
                    if(ClientNumber == 1){
                        cin >> FirstNumber;
                        big_decimal firstNumber(FirstNumber);
                        cout << "num1 = " << FirstNumber << '\n';
                        cin >> SecondNumber;
                        big_decimal secondNumber(SecondNumber);
                        cout << "SecondNumber = " << SecondNumber << '\n';
                        cout << "num1 + SecondNumber = " << firstNumber + secondNumber << '\n';

                    }

                    else if(ClientNumber == 2)
                    {
                        cin >> FirstNumber;
                        big_decimal firstNumber(FirstNumber);
                        cout << "num1 = " << FirstNumber << '\n';
                        cin >> SecondNumber;
                        big_decimal secondNumber(SecondNumber);
                        cout << "SecondNumber = " << SecondNumber << '\n';
                        cout << "num1 - SecondNumber = " << firstNumber - secondNumber << '\n';
                      ;
                    }


                else if(ClientNumber == 3)
                     {
                         program_on = false;
                        break;
                     }
                else
                    cout << "enter a valid number.\n";
            }
             catch (runtime_error& e) {
             cout << e.what();
        }
    }
    cout << "Thanks !\n";
    return 0;
}