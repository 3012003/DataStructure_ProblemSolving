
#ifndef TEST_BIG_DECIMAL_H
#define TEST_BIG_DECIMAL_H


#include <iostream>
#include <vector>
using namespace std;

class big_decimal {
private:
    string val;
    bool if_negative;
public:
    big_decimal(string);
    big_decimal(int);
    big_decimal operator+(big_decimal);
    big_decimal operator-(big_decimal);
    int size();
    big_decimal& operator=(big_decimal);
    friend ostream& operator<<(ostream&, big_decimal);
};



#endif //TEST_BIG_DECIMAL_H
