
#include "big_decimal.h"
#include <string>
big_decimal::big_decimal(string decString) {
    this->if_negative = decString.front() == '-';
    if (this->if_negative)
        decString.erase(0, 1);
    for (const char& num : decString)
        if (!isdigit(num))
            throw runtime_error(" Number not valid.\n");
    this->val = decString;
}

big_decimal::big_decimal(int decInt) {
    this->if_negative = decInt < 0;
    decInt *= this->if_negative ? -1 : 1;
    this->val = to_string(decInt);
}

big_decimal big_decimal::operator+(big_decimal else_decimal) {
    while (this->size() != else_decimal.size())
        (this->size() < else_decimal.size() ? this->val : else_decimal.val).insert(0, "0");
    if (this->if_negative && !else_decimal.if_negative)
        return big_decimal(else_decimal.val) - big_decimal(this->val);
    if (!this->if_negative && else_decimal.if_negative)
        return big_decimal(this->val) - big_decimal(else_decimal.val);
    bool is_final_result_negative = this->if_negative && else_decimal.if_negative;
    vector<int> num1 {}, num2 {};
    for (const char& number : this->val)
        num1.push_back(number - '0');
    for (const char& number : else_decimal.val)
        num2.push_back(number - '0');
    int number_carry = 0;
    string final_result;
    for (int i = num1.size() - 1; i >= 0; i--) {
        int result = number_carry + num1[i] + num2[i];
        final_result.insert(0, result >= 10 ? to_string(result % 10) : to_string(result));
        number_carry = result >= 10;
    }
    final_result.insert(0, number_carry == 1 ? "1" : "");
    return big_decimal(is_final_result_negative ? '-' + final_result : final_result);
}

big_decimal big_decimal::operator-(big_decimal else_Decimal) {
    while (this->size() != else_Decimal.size())
        (this->size() < else_Decimal.size() ? this->val : else_Decimal.val).insert(0, "0");
    if (this->if_negative && !else_Decimal.if_negative)
        return big_decimal('-' + this->val) + big_decimal('-' + else_Decimal.val);
    if (!this->if_negative && else_Decimal.if_negative)
        return big_decimal(this->val) + big_decimal(else_Decimal.val);
    if (this->if_negative && else_Decimal.if_negative)
        return big_decimal(else_Decimal.val) - big_decimal(this->val);
    bool is_final_result_negative = else_Decimal.val > this->val;
    if (is_final_result_negative)
        swap(this->val, else_Decimal.val);
    vector<int> num1 {}, num2 {};
    for (const char& number : this->val)
        num1.push_back(number - '0');
    for (const char& number : else_Decimal.val)
        num2.push_back(number - '0');
    string final_result;
    for (int i = num1.size() - 1; i >= 0; i--) {
        int j = i - 1;
        while (num1[i] < num2[i])
            num1[j] != 0 ? num1[j]--, num1[j + 1] += 10, j++ : j--;
        final_result.insert(0, to_string(num1[i] - num2[i]));
    }
    final_result.erase(0, min(final_result.find_first_not_of('0'), final_result.size() - 1));
    return big_decimal(is_final_result_negative ? '-' + final_result : final_result);
}

int big_decimal::size() {
    return this->val.length();
}

big_decimal& big_decimal::operator=(big_decimal anotherDec) {
    if (this == &anotherDec)
        return *this;
    this->val = anotherDec.val;
    return *this;
}

ostream& operator<<(ostream &out, big_decimal b) {
    return out << (b.if_negative ? '-' + b.val : b.val);
}