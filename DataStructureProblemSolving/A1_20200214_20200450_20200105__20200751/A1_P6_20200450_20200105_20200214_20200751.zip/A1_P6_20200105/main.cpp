#include <iostream>

using namespace std;

class PhoneDirectory
{
private:
    string firstName;
    string lastName;
    string phoneNum;
public:
    PhoneDirectory()
    {
        firstName=" ";
        lastName=" ";
        phoneNum=" ";
    }
    void setFirstName(string first)
    {
        firstName=first;
    }
    void setLastName(string last)
    {
        lastName=last;
    }
    void setPhoneNum(string phone)
    {
        phoneNum=phone;
    }
    string getFirstName(){return firstName;}
    string getLastName(){return lastName;}
    string getPhoneNum(){return phoneNum;}
};
struct node
{
    PhoneDirectory entry;
    node*next;
};
class LinkedList
{
private:
    node*head,*last;
public:
    LinkedList();
    void addEntery(string f, string l,string p);
    bool lookUpByName(string n);
    bool lookUpByPhoneNum(string p);
    void deleteEntry(string fn);
    void insertionSort();

    //merge sort
    void divideList(node *first1,node* &first2);
    node*mergList(node* first1,node* first2);
    void recMergeSort();

    //bubble sort
    void bubbleSort();
    void print();

};
LinkedList::LinkedList()
{
    head=NULL;
}
void LinkedList::addEntery(string f,string l,string p)
{
    node*newnode,*last;
    newnode=new node;
    newnode->entry.setFirstName(f);
    newnode->entry.setLastName(l);
    newnode->entry.setPhoneNum(p);
    newnode->next=NULL;
    if(head==NULL)
    {
        head=newnode;
        newnode->next=NULL;
    }
    else
    {
        last=head;
        while(last->next!=NULL)
        {
           last=last->next;
        }
        last->next=newnode;
        newnode->next=NULL;
    }
}
bool LinkedList::lookUpByName(string fname)
{

    bool found;
    node*current;
    current=head;
    while(current!=NULL&&!found)
    {
        if(current->entry.getFirstName()==fname){

            cout<<current->entry.getFirstName()<<endl;
            cout<<current->entry.getLastName()<<endl;
            cout<<current->entry.getPhoneNum()<<endl;
            found=true;
        }
        else{
            current=current->next;
        }
    }
    return found;

}
bool LinkedList::lookUpByPhoneNum(string phone)
{
    bool found;
    node*current;
    current=head;
    while(current!=NULL&&!found)
    {
        if(current->entry.getPhoneNum()==phone){

            cout<<current->entry.getFirstName()<<endl;
            cout<<current->entry.getLastName()<<endl;
            cout<<current->entry.getPhoneNum()<<endl;
            found=true;
        }
        else{
            current=current->next;
        }
    }
    return found;

}
void LinkedList:: deleteEntry(string fn)
{
    node*current,*tailcur;
    bool found;
    if (head == NULL){ //Case 1; the list is empty.
          cout << "Cannot delete from an empty list."<< endl;
    }
    else{
        if(head->entry.getFirstName()==fn){
            current=head;
            head=head->next;
            if(head==NULL)
                last=NULL;
            delete current;
        }
        else{
            found=false;
            tailcur=head;
            current=head->next;
            while (current != NULL && !found)
            {
                  if (current->entry.getFirstName() != fn)
                  {
                        tailcur = current;
                       current = current-> next;
                  }
                  else
                    found=true;

            }//end while
            if (found) //Case 3; if found, delete the node
            {
                tailcur->next = current->next;
                if (last == current) //node to be deleted was the
               //last node
                     last = tailcur; //update the value of last
                delete current; //delete the node from the list
             }
             else
                 cout << "The item to be deleted is not in "<< "the list." << endl;
        }
    }
}
void LinkedList::divideList(node *first1,node* &first2)
{
    node* middle;
    node *current;
    if (first1 == NULL) //list is empty
         first2 = NULL;
    else if (first1->next == NULL) //list has only one node
        first2 = NULL;
    else
    {
        middle = first1;
        current = first1->next;
        if (current != NULL) //list has more than two nodes
             current = current->next;
        while (current != NULL)
        {
            middle = middle->next;
            current = current->next;
            if (current != NULL)
                  current = current->next;
        } //end while
        first2 = middle->next; //first2 points to the first
        //node of the second sublist
        middle->next= NULL; //set the link of the last node
    }

}
node* LinkedList::mergList(node*first1,node*first2)
{
    node*lastSmall; //pointer to the last node of
    node *newHead; //pointer to the merged list
    if (first1 == NULL) //the first sublist is empty
         return first2;
    else if (first2 == NULL) //the second sublist is empty
          return first1;
    else
    {
            if (first1->entry.getFirstName() < first2->entry.getFirstName()) //compare the first nodes
            {
                 newHead = first1;
                 first1 = first1->next;
                 lastSmall = newHead;
            }
            else
            {
                newHead = first2;
                first2 = first2->next;
                lastSmall = newHead;
            }
           while (first1 != NULL && first2 != NULL)
           {
                if (first1->entry.getFirstName() < first2->entry.getFirstName())
                {
                       lastSmall->next= first1;
                       lastSmall = lastSmall->next;
                       first1 = first1->next;
                }
                else
                {
                     lastSmall->next = first2;
                     lastSmall = lastSmall->next;
                     first2 = first2->next;
                }
           } //end while
           if (first1 == NULL) //first sublist is exhausted first
                 lastSmall->next = first2;

          else //second sublist is exhausted first
                 lastSmall->next = first1;
         return newHead;
    }
}
void LinkedList::recMergeSort()
{
    node *otherHead;
    if (head != NULL) //if the list is not empty
    if (head->next!= NULL) //if the list has more than one node
    {
         divideList(head, otherHead);
         recMergeSort();
         recMergeSort();
         head = mergList(head, otherHead);
    }
}
void LinkedList::insertionSort()
{
    node *lastInOrder;
    node *firstOutOfOrder;
    node *current;
    node *trailCurrent;
    lastInOrder = head;
    if(head==NULL)
        cout<<"the list is empty"<<endl;
    else if (head->next == NULL)
            cout << "The list is of length 1."<< endl;
    else
       while (lastInOrder->next != NULL)
       {
           firstOutOfOrder = lastInOrder->next;
           if (firstOutOfOrder->entry.getFirstName() < head->entry.getFirstName())
           {
                lastInOrder->next = firstOutOfOrder->next;
                firstOutOfOrder->next= head;
                head = firstOutOfOrder;
           }
           else
           {
               trailCurrent = head;
               current = head->next;
               while (current->entry.getFirstName() < firstOutOfOrder->entry.getFirstName())
               {
                    trailCurrent = current;
                    current = current->next;
               }
               if (current != firstOutOfOrder)
               {
                    lastInOrder->next= firstOutOfOrder->next;
                    firstOutOfOrder->next= current;
                    trailCurrent->next = firstOutOfOrder;
               }
               else
                   lastInOrder = lastInOrder->next;
           }
      }
}

void LinkedList::bubbleSort()
{
    node*current;
    current=head->next;

   while(current!=NULL)
   {
       node* prev =NULL;
    node*cur = head;
    while(cur->next!=NULL)
    {
        if(cur->entry.getFirstName() >=cur->next->entry.getFirstName())
        {

            if(prev==NULL)
            {
                //first node
                node* nxt = cur->next ;
                cur->next = nxt->next ;
                nxt->next = cur ;
                prev=nxt ;
                head = prev ;


            }
            else
            {

                node* nxt = cur->next ;
                prev->next = nxt ;
                cur->next = nxt->next ;
                nxt->next = cur ;
                prev = nxt ;


            }

        }
        else
        {

             prev = cur ;
            cur=cur->next ;
         }



    }
    current=current->next;

   }



}
void LinkedList::print()
{
    node *currentn;
    if(head==NULL){
        cout<<" the list is empty "<<endl;
    }
    else{
            currentn=head;
            while(currentn!=NULL){
                cout << currentn->entry.getFirstName() <<"     ";
                cout << currentn->entry.getLastName() << "     ";
                cout << currentn->entry.getPhoneNum();
                currentn=currentn->next;
                cout<<endl;
            }
    }
}

int main()
{
    string firstname,lastname,phonenum;
    LinkedList obj;
    int oper;
    while(true)
    {
        cout<<"please enter which operation do you want to do"<<endl;
        cout<<"such as add an entry=1, Look up a phone number=2, Look up by first name=3, delete an entry=4"<<endl;
        cout<<"list all entry=5, exit=6 :";
        cin>>oper;
        if(oper==1)
        {
            cout<<"please enter the first name: ";
            cin>>firstname;
            cout<<"please enter the last name: ";
            cin>>lastname;
            cout<<"please enter phone number: ";
            cin>>phonenum;
            obj.addEntery(firstname,lastname,phonenum);

        }
        else if(oper==2)
        {
            string phone;
            cout<<"please enter the phone number you are locking for: ";
            cin>>phone;
            obj.lookUpByPhoneNum(phone);

        }
        else if(oper==3)
        {
            string fname;
            cout<<"please enter the first name you are locking for: ";
            cin>>fname;
            obj.lookUpByName(fname);

        }
        else if(oper==4)
        {
            string Name;
            cout<<"please enter the name"<<endl;
            cin>>Name;
            int nu;
            cout<<"please enter which type do you want to use to sort the list"<<endl;
            cout<<"insertion sort=1, merge sort=2, bubble sort=3"<<endl;
            cin>>nu;
            if(nu==1){
                   obj.insertionSort();
                   obj.deleteEntry(Name);
            }
            else if(nu==2){
                obj.recMergeSort();
                obj.deleteEntry(Name);
            }
            else if(nu==3){
                obj.bubbleSort();
                obj.deleteEntry(Name);
            }
        }
        else if(oper==5)
        {
            int num;
            cout<<"please enter which type do you want to use to sort the list"<<endl;
            cout<<"insertion sort=1, merge sort=2, bubble sort=3"<<endl;
            cin>>num;
            if(num==1){
                   obj.insertionSort();
                   obj.print();
            }
            else if(num==2){
                obj.recMergeSort();
                obj.print();
            }
            else if(num==3){
                obj.bubbleSort();
                obj.print();
            }
        }
        else if(oper==6)
        {
            cout<<" EXIT "<<endl;
            exit(0);

        }

    }

    return 0;
}
